import java.util.*; // 導入Java => [ 如果用VSCode可省略 ]

public class Hajime{ // 宣告 | 命名 => 一個類 => [ 須與檔名完全相同 ]
    public static void main (String args[]){ // 主方法 [ Method ]

        System.out.println(">>> HI JAVA || I'm JEFF LIU <<<"); // 由系統輸出至 WIN => CMD | MAC => Terminal 
        System.out.println("！ 這是我第一個用Java寫的程式 ！"); 

        System.out.println("！ 感覺有點新奇 因為寫起來比Py複雜不少 ！"); // 動機 | 感受
        System.out.println("！ 但我希望我會寫更多種程式 ！"); // 增加自己的Creativity
        System.out.println("！ 不但可以用更好玩的方式動腦 ！"); // 比算數學好多了
        System.out.println("！ 還可以能看得懂更多大佬的作品 ！"); // Github上的Open Source

        System.out.println("！ 至於想寫的程式還不是很確定 ！"); // 想寫的程式
        System.out.println("！ 可能是遊戲的模組或插件 ！"); // Minecraft的

        System.out.println("！ 至於寫程式的過程沒什麼太大的問題 ！"); // 過程遇到的問題 ？
        System.out.println("！ 且VSCode的插件把人工Compile的過程省略掉了 ！"); // 不確定是插件還是本來就會直接運行了

    }//main() 結尾
}//class 結尾